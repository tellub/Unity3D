<?php
    // create the connection to our database with following values: location of our databse
    // (with xampp it's "localhost"), next is the login ("name" and "password").
    // if the connection can not be established we get an error message, that we've entered after "or die"
    $username = "root";
    $password = "";
    $database = "UnityDB";

    //Create connection
    $con = mysqli_connect("localhost", $username, $password, $database);

    //Check connection
    if (mysqli_connect_errno())
    {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }
    
    // now we store our sent information from Unity in php variables, we can work with
    $score = $_POST['newScore'];
    $name = $_POST['newName'];
    

    $sql="INSERT INTO highscores (Name, Score) VALUES ('$name', '$score')";
    
    $result = mysqli_query($con, $sql);
    
    if($result) {
        print("User '$myusername' created");   
    }
    
    // Close connection    
    mysqli_close($con);
?>